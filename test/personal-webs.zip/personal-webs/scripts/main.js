let header = document.querySelector(".header");
let nav_button = header.querySelector(".top_sheet");
let nav = header.querySelector(".topb_box");
window.addEventListener("selectstart",function (event){
    event.preventDefault();
});
nav_button.addEventListener("click",function (){
    nav.classList.toggle("show_flex");
});

// 能力图谱
const map = [
    ["C/C++"],
    ["Python"],
    ["Javascript"],
    ["C/C++","C51嵌入式开发"],
    ["C/C++","QT-C++"],
    ["C/C++","Apollo/Auto竞赛"],
    ["Python","机器学习"],
    ["Javascript","HTML5/CSS3"],
    ["Javascript","DOM/BOM"],
    ["Javascript","Electron"]
];
let map_ptr = [];
let browser = document.querySelector(".browser");
let back = document.querySelector(".skills .back");
function createListFromPtr(){
    // 清空
    browser.innerHTML = "";
    // 根据ptr装载
    for (const mapElement of map) {
        if (mapElement.length === map_ptr.length+1 &&
            mapElement.slice(0,map_ptr.length).join()===map_ptr.join()) {
            let li = document.createElement("li");
            li.innerHTML = mapElement[mapElement.length-1];
            li.addEventListener("click",function (){
               map_ptr.push(this.innerHTML);
               createListFromPtr();
            });
            browser.appendChild(li);
        }
    }
}
back.addEventListener("click",function (){
   map_ptr.pop();
   createListFromPtr();
});
createListFromPtr();

// 联系方式复制
let copy = document.querySelectorAll(".contact .card .copy");
for (const copyElement of copy) {
    copyElement.addEventListener("click",function (){
       let text = this.parentElement.querySelector("span");
       navigator.clipboard.writeText(text.innerHTML);
    });
}

// 导航快速跳转
let buttons = document.querySelector(".header .topb_box");
let about = document.querySelector(".mainbody .short_intro");
let skills = document.querySelector(".mainbody .skills");
let contact = document.querySelector(".mainbody .contact");
buttons.children[0].addEventListener("click",function (){
    about.scrollIntoView({
        behavior:"smooth",
        block:"start"
    });
});buttons.children[1].addEventListener("click",function (){
    skills.scrollIntoView({
        behavior:"smooth",
        block:"start"
    });
});buttons.children[2].addEventListener("click",function (){
    contact.scrollIntoView({
        behavior:"smooth",
        block:"start"
    });
});